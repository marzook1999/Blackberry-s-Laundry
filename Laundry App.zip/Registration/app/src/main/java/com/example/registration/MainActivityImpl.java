package com.example.registration;

public class MainActivityImpl extends MainActivity {
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
