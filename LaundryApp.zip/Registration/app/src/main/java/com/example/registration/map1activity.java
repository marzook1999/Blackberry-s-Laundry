package com.example.registration;

public class map1activity {

    private boolean mLocationPermissionGranted = false;
}
